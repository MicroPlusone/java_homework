import java.awt.*;

public class Input extends Frame {
    public Input(){//这是一个构造器，不是成员方法！
        super("成绩录入");
        this.setSize(1920,1080);
        this.setBackground(Color.gray);
        this.setLayout(new FlowLayout());
        this.setLocation(0,0);

        this.add(new Label("学生学号"));
        this.add(new TextField("student1",1000));
        this.add(new Label("密码"));
        this.add(new TextField(1000));
        this.add(new Button("OK"));
        this.add(new Button("Cancel"));
        this.setVisible(true);

    }
    public static void main(String[] args) {
        new Input();
    }
}