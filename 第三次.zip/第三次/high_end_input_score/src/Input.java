import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Input extends JFrame implements ActionListener {
    private JTextField studentIDField;
    private JTextField scoreField;
    private JButton enterButton;
    private JList<String> gradeList;
    private DefaultListModel<String> listModel;
    public Input(){
        studentIDField = new JTextField(100);
        scoreField= new JTextField(100);
        enterButton=new JButton("input");
        listModel=new DefaultListModel<>();
        gradeList=new JList<>(listModel);

        enterButton.addActionListener(this);

        setLayout(new FlowLayout());
        add(new JLabel("ID:"));
        add(studentIDField);
        add(new JLabel("score:"));
        add(scoreField);
        add(enterButton);
        add(new JScrollPane(gradeList));

        setTitle("Input");
        setSize(1920,1080);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String studentID=studentIDField.getText();
        String scoreStr=scoreField.getText();
        try{
            int score=Integer.parseInt(scoreStr);
            if(score<0||score>100){
                throw new IllegalAccessException("The score must be between 0 and 100!");

            }
            listModel.addElement((studentID+": "+score));

        } catch (IllegalAccessException ex) {
            throw new RuntimeException(ex);
        }catch(NumberFormatException nfe){
            JOptionPane.showMessageDialog(this,"please input an integer!");

        }catch (IllegalArgumentException iae){
            JOptionPane.showMessageDialog(this,iae.getMessage());
        }

    }

    public static void main(String[] args) {
        new Input();
    }
}